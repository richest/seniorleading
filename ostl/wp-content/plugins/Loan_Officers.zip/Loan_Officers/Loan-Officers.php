<?php
/*
Plugin Name: Loan Officers
Plugin URI: http://www.julianjosephs.com
Description: Declares a plugin that will create a custom post type displaying loan officers and loan teams.
Version: 1.0
Author: Julian Josephs
Author URI: http://www.julianjosephs.com
License: GPLv2
*/

flush_rewrite_rules();

add_action( 'init', 'create_loan_officers' );

function create_loan_officers() {
    register_post_type( 'loan_officers',
        array(
            'labels' => array(
                'name' => 'Loan Officers',
                'singular_name' => 'Loan Officer',
                'add_new' => 'Add New',
                'add_new_item' => 'Add New Loan Officer',
                'edit' => 'Edit',
                'edit_item' => 'Edit Loan Officer',
                'new_item' => 'New Loan Officer',
                'view' => 'View',
                'view_item' => 'View Loan Officer',
                'search_items' => 'Search Loan Officers',
                'not_found' => 'No Loan Officers found',
                'not_found_in_trash' => 'No Loan Officers found in Trash',
                'parent' => 'Parent Loan Officer'
            ),
 
            'public' => true,
            'menu_position' => 15,
            'supports' => array( 'title', 'editor', 'comments', 'thumbnail', 'custom-fields' ),
            'taxonomies' => array( '' ),
            'menu_icon' => plugins_url( 'images/image.png', __FILE__ ),
            'has_archive' => true
        )
    );
}

?>